cc.Class({
    extends: cc.Component,
    properties: {
        player: {
            default: null,
            type: cc.Node
        },

        cardPrefab: {
            default: null,
            type: cc.Prefab
        },
        ordered: {
            default: [],
            type: cc.Node
        },
        unKnow: {
            default: null,
            type: cc.Node
        },
        knowFromUnknow: {
            default: null,
            type: cc.Node
        },
        ordering: {
            default: [],
            type: cc.Node
        }
    },

    ctor: function () {
        this.allCardNode = [];
        this.moveCardNodes = [];
        this.isCardAnimation = false;
    },

    initDisplayAllCard: function () {
        var allCards = PlayerCardsManager.getInstance().allCards;
        for (var key in CardPosKind) {
            switch (CardPosKind[key]) {
                case CardPosKind.ordered:
                    break;
                case CardPosKind.unKnow:
                    var pos = this.unKnow.getPosition();
                    for (var i = 0; i < allCards[key].length; i++) {
                        var card = cc.instantiate(this.cardPrefab);
                        card.getComponent('card').setCardInfo(allCards[key][i]);
                        card.setPosition(pos);
                        card.setLocalZOrder(i);
                        card.parent = this.node;
                        this.allCardNode.push(card);
                    }
                    break;
                case CardPosKind.knowFromUnknow:
                    break;
                case CardPosKind.ordering:
                    for (var i = 0; i < allCards[key].length; i++) {
                        var pos = this.ordering[i].getPosition();
                        for (var j = 0; j < allCards[key][i].length; ++j) {
                            var card = cc.instantiate(this.cardPrefab);
                            card.getComponent('card').setCardInfo(allCards[key][i][j]);
                            card.setPosition(pos);
                            card.runAction(cc.moveTo(0.3, cc.p(pos.x, pos.y - j * ordering_with)));
                            card.parent = this.node;
                            this.allCardNode.push(card);
                        }
                    }
                    break;
            }
        }
    },

    onLoad: function () {
        this.node.on('touchstart', this.onTouchStart, this);
        this.node.on('touchmove', this.onTouchMove, this);
        this.node.on('touchend', this.onTouchEnded, this);
        this.initDisplayAllCard();
    },

    onTouchStart: function (event) {
        if (this.isCardAnimation) {
            return;
        }
        var touchPos = this.node.convertTouchToNodeSpaceAR(event.touch);
        for (var key in CardPosKind) {
            switch (CardPosKind[key]) {
                case CardPosKind.ordered:
                    break;
                case CardPosKind.unKnow:
                    if (this.unKnow.getBoundingBox().contains(touchPos)) {
                        this.handleTouchUnknow();
                    }
                    break;
                case CardPosKind.knowFromUnknow:
                    if (this.knowFromUnknow.getBoundingBox().contains(touchPos)) {
                        this.handleTouchKnowFromUnknow();
                    }
                    break;
                case CardPosKind.ordering:
                    var result = this.isPointInOrderingArea(touchPos)
                    if (result) {
                        this.handleTouchOrdering(result.areaCardKindIndex, result.startIndex);
                    }
                    break;
            }
        }
        return true;
    },

    /**
     * 
    */
    isPointInOrderingArea: function (point) {
        for (var i = 0; i < this.ordering.length; ++i) {
            var rect = this.ordering[i].getBoundingBox();
            if ((rect.x < point.x) && (point.x < rect.x + rect.width)) {
                var orderingCard = PlayerCardsManager.getInstance().allCards.ordering[i];
                var max_y = rect.y + card_height;
                var min_y = max_y - (orderingCard.length - 1) * ordering_with - card_height;  // 计算高度有效点击范围；
                if (min_y < point.y && point.y < max_y) {
                    var offset_y = (rect.y + card_height) - point.y
                    var touchIndex = Math.floor(offset_y / ordering_with);
                    var startIndex = Math.min(touchIndex, orderingCard.length - 1);
                    var result = {
                        'areaCards': orderingCard,   // 目标区域牌的集合
                        'areaCardKindIndex': i,      // 目标区域可能多组牌，对应的index
                        'startIndex': startIndex,    // 触目具体哪个组的那张牌的索引值
                        'canLink': false,            // 排至能否链接上；
                        'areaCardPosKind': CardPosKind.ordering // 目标区域的牌的种类；
                    };
                    return result;
                }
            }
        }
        return null;
    },

    onTouchMove: function (event) {
        var deltaPos = event.getDelta();
        for (var i = 0; i < this.moveCardNodes.length; ++i) {
            var pos = this.moveCardNodes[i].getPosition();
            this.moveCardNodes[i].setLocalZOrder(MOVE_CARD_ZORDER + this.moveCardNodes[i].originZOrder);
            this.moveCardNodes[i].setPosition(cc.pAdd(pos, deltaPos))
        }
    },

    onTouchEnded: function (event) {
        var starPos = this.node.convertToNodeSpaceAR(event.getStartLocation());
        var curPos = this.node.convertToNodeSpaceAR(event.getLocation());
        this.linkCardNode(tarPos, curPos);
        this.playerCardAnimation();
    },

    getCardNodeByCardData: function (cardData) {
        for (var i = 0; i < this.allCardNode.length; ++i) {
            if (cardData == this.allCardNode[i].getComponent('card').cardData) {
                return this.allCardNode[i];
            }
        }
        return null;
    },

    addMoveCardNode: function (moveCardNode) {
        this.moveCardNodes.push(moveCardNode);
        moveCardNode.originZOrder = moveCardNode.getLocalZOrder();
    },

    handleTouchUnknow: function () {
        var unknowCards = PlayerCardsManager.getInstance().allCards.unKnow;
        var knowFromUnknow = PlayerCardsManager.getInstance().allCards.knowFromUnknow;
        if (unknowCards.length > 0) {
            var pos = this.knowFromUnknow.getPosition();
            var cardNode = this.getCardNodeByCardData(unknowCards[unknowCards.length - 1]);
            if (cardNode) {
                var cardComponent = cardNode.getComponent('card');
                cardComponent.cardData.posKind = CardPosKind.knowFromUnknow;
                cardComponent.cardData.isSee = true;
                cardComponent.setCardInfo(cardComponent.cardData);
                cardNode.setLocalZOrder(knowFromUnknow.length + unknowCards.length);
                cardNode.runAction(cc.sequence(cc.moveTo(0.1, pos), cc.callFunc(function (sender) {
                    sender.setLocalZOrder(knowFromUnknow.length)
                })));

                var deletCardData = unknowCards.splice(unknowCards.length - 1, 1);
                knowFromUnknow.push(deletCardData[0]);
            }
        } else {
            var pos = this.unKnow.getPosition();
            for (var i = 0; i < knowFromUnknow.length; ++i) {
                var cardNode = this.getCardNodeByCardData(knowFromUnknow[i]);
                if (cardNode) {
                    cardNode.setPosition(pos);
                    cardNode.setLocalZOrder(knowFromUnknow.length - i);
                    var cardComponent = cardNode.getComponent('card');
                    cardComponent.cardData.posKind = CardPosKind.unKnow;
                    cardComponent.cardData.isSee = false;
                    cardNode.getComponent('card').setCardInfo(cardComponent.cardData);
                }
            }
            PlayerCardsManager.getInstance().allCards.unKnow = knowFromUnknow.reverse();
            PlayerCardsManager.getInstance().allCards.knowFromUnknow = [];
        }
    },

    handleTouchKnowFromUnknow: function () {
        var unknowCards = PlayerCardsManager.getInstance().allCards.unKnow;
        var knowFromUnknow = PlayerCardsManager.getInstance().allCards.knowFromUnknow;
        var cardNode = this.getCardNodeByCardData(knowFromUnknow[knowFromUnknow.length - 1]);
        cardNode.starPos = cardNode.getPosition();
        this.addMoveCardNode(cardNode);
    },

    handleTouchOrdering: function (orderingIndex, touchCardIndex) {
        var orderingCard = PlayerCardsManager.getInstance().allCards.ordering;
        var touchedCards = orderingCard[orderingIndex];
        if (touchedCards[touchCardIndex].isSee) {
            for (var i = touchCardIndex; i < touchedCards.length; ++i) {
                var card = this.getCardNodeByCardData(touchedCards[i]);
                if (card && touchedCards[i].isSee) {
                    card.starPos = card.getPosition();
                    this.addMoveCardNode(card);
                }
            }
        }
    },

    linkCardNode: function (starPos, endPos) {
        if (this.moveCardNodes.length != 0) {
            var cardData = this.moveCardNodes[0].getComponent('card').cardData;
            if (cardData.posKind == CardPosKind.knowFromUnknow) {
                var result = this.isPointInOrderingArea(endPos);
                result.canLink = this.canLinkCardData(cardData, result.areaCards[result.areaCards.length - 1]);
            } else if (cardData.posKind == CardPosKind.ordering) {

            }
        }

        if (result && result.canLink) {
            /*var result = {
                                'areaCards': orderingCard,   // 目标区域牌的集合
                                'areaCardKindIndex': i,      // 目标区域可能多组牌，对应的index
                                'startIndex': startIndex,    // 触目具体哪个组的那张牌的索引值
                                'canLink': false,            // 排至能否链接上；
                                'areaCardPosKind': CardPosKind.ordering // 目标区域的牌的种类；
           };*/


        }
    },

    canLinkCardData: function (moveCardData, targetCardData) {
        if (moveCardData.value - targetCardData.value == 1) {
            var m_kind = moveCardData.kind;
            var t_kind = targetCardData.kind;
            var b_temp = (m_kind == m_kind.spade || m_kind == CardKind.club) && (m_kind == CardKind.heart || t_kind == CardKind.diamond);
            b_temp &= (t_kind == CardKind.spade || t_kind == CardKind.club) && (m_kind == CardKind.heart || m_kind == CardKind.diamond);
            return b_temp1;
        }
        return false;
    },

    handleCanLink: function name() {

    },

    playerCardAnimation: function (desPos) {
        var self = this;
        for (var i = 0; i < this.moveCardNodes.length; ++i) {
            var targetPos = desPos ? desPos : this.moveCardNodes[i].starPos;
            var moveAni = cc.moveTo(0.2, targetPos);
            var callBack = cc.callFunc(function (sender) {
                sender.setLocalZOrder(sender.originZOrder);
                self.isCardAnimation = false;
            })
            this.moveCardNodes[i].runAction(cc.sequence(moveAni, callBack));
        }
        this.moveCardNodes = [];
    }

});
