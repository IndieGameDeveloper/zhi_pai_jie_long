var CardValue = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];

class PlayerCardsManager {
  static getInstance() {
    if (!PlayerCardsManager._instance) {
      PlayerCardsManager._instance = new PlayerCardsManager();
    }
    return PlayerCardsManager._instance;
  }

  constructor() {
    this.allCards = {};
    for (var key in CardPosKind) {  // 初始化位置的种类
      this.allCards[key] = [];
    };

    this.initPlayerCards();
    this.initUnknowCards();
    this.initOrderingCards();
    this.initOrderedCards();
  }

  initPlayerCards() {   //初始化牌的值，种类
    this.playerCards = [];
    for (var i in CardKind) {
      for (var j = 0; j < CardValue.length; ++j) {
        var cardTemp = new CardData(CardValue[j], CardKind[i], 0, false);
        this.playerCards.push(cardTemp);
      }
    }
  }

  initUnknowCards() {   //右上角未翻开的牌
    for (var i = 0; i < 24; ++i) {
      var randomIndex = Math.floor(Math.random() * this.playerCards.length);
      var cardData = this.playerCards[randomIndex];
      cardData.posKind = CardPosKind.unKnow;
      this.allCards.unKnow.push(cardData);
      this.playerCards.splice(randomIndex, 1);
    }
    // console.log(this.allCards.unKnow)
  }

  initOrderingCards() { //正在排序的拍
    for (var i = 0; i < 7; ++i) {
      this.allCards.ordering.push(new Array());
      for (var k = 0; k <= i; ++k) {
        var randomIndex = Math.floor(Math.random() * this.playerCards.length);
        var card = this.playerCards[randomIndex];
        card.posKind = CardPosKind.ordering;
        card.isSee = true;
        this.allCards.ordering[i].push(card);
        this.playerCards.splice(randomIndex, 1);
      }
      this.allCards.ordering[i][i].isSee = true;
    }
  }

  initOrderedCards() {
    for (var i = 0; i < 4; ++i) {
      this.allCards.ordered[i] = [];
    }
  }
};


window.PlayerCardsManager = PlayerCardsManager;